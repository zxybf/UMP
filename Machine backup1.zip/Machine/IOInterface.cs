﻿//*****************************************************************************
//*         FILE: IOInterface.cs
//*       AUTHOR: xinyiz163@163.com
//*         DATE: Dec 2019
//*  DESCRIPTION: 所有的IO在这里定义，定义的时候由于可能所有的项目IO都在这里，
//*               可以定义重复的IObit硬件端，但是实例的时候就不能重复
//*               比如：定义了一个Nest类，Nest类定义了NestVac12OK端口为Galil ouput8
//*                     以后不能再次定义Galil1的端口8了
//*****************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Machine
{
    public enum IoBitId_T
    {
        // GALIL 1 (DMC-4050) Module INPUTS
        SystemAirOK,
        FrontDoorSafe1, FrontDoorSafe2, FrontDoorClosed,
        RearDoorSafe1, RearDoorSafe2, RearDoorClosed,
        EstopButtonOK,
        NestVac12OK, NestVac34OK,
        LeftXferVacOK, RightXferVacOK,
        GearingGoNow,
        EstopRelayOK,
        RobotLoadEStopOK, RobotUnloadEStopOK,
        // T1 stuff
        SMACPartPresent, SMACGripperExtended,
        NestPartPresent12, NestPartPresent34,

        /////////////////////////////////////////////////////////////////////////
        // GALIL 1 (DMC-4050) Module OUTPUTS
        ActivateNestVacLeft, ActivateNestPufLeft,
        ActivateNestVacRight, ActivateNestPufRight,
        ActivateXferVac, ActivateXferPuf,
        //Spare1Y07,          Spare1Y08,
        OpenSnuggers, LJVReset,
        GearingTrigger, AbortOutput,
        LJV_PRG_1, LJV_PRG_2,
        LJV_PRG_3, LJV_PRG_4,
        // T1 stuff
        ExtendZClamps, ExtendSMACNestGripper,
        ExtendShortSideFingers, ExtendLongSideFingers,

        /////////////////////////////////////////////////////////////////////////
        // GALIL 1 Extended I/O CAMERA/LASER TRIGGER OUTPUTS - DO NOT USE FROM C#
        // C = Camera (1..4 on XG1, 5..8 on XG2, 9..12 on XG3, 13..16 on XG4
        // L = Laser Controller
        // S = Spare
        // XG1C1,XG1C2,XG1C3,XG1C4,XG2C1,XG2C2,XG2C3,XG2C4,   // 1Y17 .. 1Y24 XG1 & XG2 Camera Triggers
        // XG3C1,XG3C2,XG3C3,XG3C4,XG4C1,XG4C2,XG4C3,XG4C4,   // 1Y25 .. 1Y32 XG3 & XG4 Camera Triggers
        // LJ1,LJ2,LJ3,LJ4,LJ5,LJ6,LJ7,LJ8,                   // 1Y33 .. 1Y40 Laser Triggers

        /////////////////////////////////////////////////////////////////////////
        // GALIL 2 (DMC-4040) Optional Xfer INPUTS
        LeftBridgeVacOK,
        RightBridgeVacOK,
        //Spares 2X03 ... 2X08, 2X33...2X48

        /////////////////////////////////////////////////////////////////////////
        // GALIL 2 (DMC-4040) Optional Xfer OUTPUTS
        ActivateLeftBridgeVac, ActivateLeftBridgePuff,
        ActivateRightBridgeVac, ActivateRightBridgePuff,
        //Spares 2Y05 ... 2Y08, 2Y17...2Y32


        /////////////////////////////////////////////////////////////////////////
        // Robot1/2 (Load/Unload) Inputs
        R1_EstopButtonOK, R2_EstopButtonOK,       // C#/RBT
        R1_EstopRelayOK,      //R2_EstopRelayOK,        // C#/RBT
        R1_DoorSafe1, R2_DoorSafe1,           // C#/RBT
        R1_DoorSafe2, R2_DoorSafe2,           // C#/RBT
        R1_DoorClosed, R2_DoorClosed,          // C#/RBT
        R1_PartPresent, R2_PartCleared,         // RBT
        R1_PartPresence, R2_PartPresence,
        R1_Bcr1ReadOK, R2_SpareX06,
        R1_Bcr2ReadOK,        //R2_SpareX07,
        R1_Vac1OK, R2_Vac1OK,              // RBT
        R2_UPS_LOW_BATTERY,
        R2_UPS_ON_BATTERY_POWER,
        R1_Cup1Extended, R2_Cup1Extended, //R2_SpareX10,
        R1_Vac2OK, R2_Vac2OK,              // RBT
        R1_XSlideExtended,    //R2_SpareX12,            
        R1_Cup2Extended, R2_Cup2Extended, //R2_SpareX13,
        R1_XSlideRetracted,   //R2_SpareX14,
        R1_ConveyorClear, R2_ConveyorClear,       // RBT
                                                  //R1_SpareX16,            R2_SpareX16,
        R1_ConveyorOK, R2_ConveyorOK,
        R1_Bcr3ReadOK,        //R2_SpareX18,
        R1_Bcr4ReadOK,        //R2_SpareX19,
                              //R1_SpareX20,            R2_SpareX20,
                              //R1_SpareX21,            R2_SpareX21,
                              //R1_SpareX22,            R2_SpareX22,
                              //R1_SpareX23,            R2_SpareX23,
        R1_Gripper1Retracted, R2_Gripper1Retracted,
        R1_Gripper2Retracted, R2_Gripper2Retracted,


        // Robot1/2 (Load/Unload) Outputs
        R1_ActivateTaskLight, R2_ActivateTaskLight,   // C#
        R1_RunConveyor, R2_RunConveyor,         // RBT
                                                //R1_SpareY02,            R2_SpareY02,
        R1_ExtendXslide,      //R2_SpareY03,
        R1_ActivateVisionLT,  //R2_SpareY04,
        R1_RetractXslide,     //R2_SpareY05,
        R1_TriggerBCR1,       //R2_SpareY06,
        R1_TriggerBCR2,       //R2_SpareY07,
        R1_ActivateVac1, R2_ActivateVac1,        // RBT
        R1_ActivatePuff1, R2_ActivatePuff1,       // RBT
        R1_ExtendCup1, R2_ExtendCup1, //R2_SpareY10,
        R1_RetractCup1, R2_RetractCup1, //R2_SpareY11,
        R1_ExtendEndeffector1,
        R1_RetractEndeffector1,
        R1_ActivateVac2, R2_ActivateVac2,        // RBT
        R1_ActivatePuff2, R2_ActivatePuff2,       // RBT
        R1_ExtendCup2, R2_ExtendCup2, //R2_SpareY14,
        R1_RetractCup2, R2_RetractCup2, //R2_SpareY15,
        R1_Gripper1Retract, R2_Gripper1Retract,
        R1_Gripper2Retract, R2_Gripper2Retract,
        R1_Gripper1Extend, R2_Gripper1Extend,
        R1_Gripper2Extend, R2_Gripper2Extend,

        /////////////////////////////////////////////////////////////////////////
        // GALIL COLOR MODULE (DMC-4020) Module OUTPUTS
        /// /////////////////////////////////////////////////////////////////////////
        // Saftey
        CM_FrontDoorSafe1, CM_FrontDoorSafe2, CM_FrontDoorClosed,
        CM_RearDoorSafe1, CM_RearDoorSafe2, CM_RearDoorClosed,
        CM_EstopRelayOk, CM_LocalEstopOk,
        // Measure

        // End effector

        CM_Vac1Ok, CM_Cup1Extended,
        CM_Vac2Ok, CM_Cup2Extended,

        CM_NestVacOk, CM_NestExtended, CM_NestRetracted, CM_PartPresent1, CM_PartPresent2,
        CMAirOK,

        CM_ActivateVac1, CM_ActivatePuff1, CM_ExtendCup1, CM_RetractCup1,
        CM_ActivateVac2, CM_ActivatePuff2, CM_ExtendCup2, CM_RetractCup2,
        CM_ActivateMeasure, CM_ActivateNestVac, CM_ActivateNestPuff, CM_ExtendNest,
        CM_RetractNest,

        CM_TriggerBCR1,
        CM_TriggerBCR2,

        CM_BRC1_OK,
        CM_BRC2_OK,




        /////////////////////////////////////////////////////////////////////////
        // GALIL U MODULE (DMC-4050) 
        /// /////////////////////////////////////////////////////////////////////////
        // INPUTS

        UM_LocalEstopOk,
        //UM_GearingTriggerInput,

        // OUTPUTS
        UM_ActivateEndeff1Vac,
        UM_ActivateEndeff1Puff,
        UM_ActivateEndeff2Vac,
        UM_ActivateEndeff2Puff,
        UM_ActivateEjector12Vac,
        UM_ActivateEjector12Puff,
        UM_ExtendEjector12,
        UM_RetractEjector12,
        UM_ResetLasers,
        //UM_GearingTriggerOutput,
        //UM_StopAxisE,
        //UM_LjvProgramOut1,
        //UM_LjvProgramOut2,
        //UM_LjvProgramOut3,
        //UM_LjvProgramOut4,


        UM_PartPresent_1,
        UM_PartPresent_2,
        UM_PartPresent_3,
        UM_PartPresent_4,


        /////////////////////////////////////////////////////////////////////////
        // RIO U MODULE (RIO -47300) 
        /// /////////////////////////////////////////////////////////////////////////

        // INPUTS
        UM_Nest1VacOk,
        UM_RotatorVacOk,
        UM_Nest3VacOk,
        UM_Nest4VacOk,
        UM_Endeff1VacOk,
        UM_Endeff2VacOk,
        UM_Ejector12VacOk,
        UM_Ejector12Extended,
        UM_Ejector12Retracted,
        UM_Endeff3VacOk,
        UM_Endeff4VacOk,
        UM_Ejector34VacOk,
        UM_Ejector34Extended,
        UM_Ejector34Retracted,
        //UM_PartPresent1,
        //UM_PartPresent2,
        //UM_PartPresent3,
        //UM_PartPresent4,
        UM_Nest2VacOk,
        UM_BRC_1_OK,
        UM_BRC_2_OK,


        // OUTPUTS
        UM_ActivateNest1Vac,
        UM_ActivateNest1Puff,
        UM_Open12Fingers,
        UM_ActivateRotatorVac,
        UM_ActivateRotatorPuff,
        UM_Open34Fingers,
        UM_ActivateNest3Vac,
        UM_ActivateNest3Puff,
        UM_ActivateNest4Vac,
        UM_ActivateNest4Puff,
        UM_ActivateEndeff3Vac,
        UM_ActivateEndeff3Puff,
        UM_ActivateEndeff4Vac,
        UM_ActivateEndeff4Puff,
        UM_ActivateEjector34Vac,
        UM_ActivateEjector34Puff,
        UM_ExtendEjector34,
        UM_RetractEjector34,
        UM_ActivateNest2Vac,
        UM_ActivateNest2Puff,
        UM_TriggerBCR_1,
        UM_TriggerBCR_2,

        NUM_IO
    }
    static public class IOInterface
    {
        /// <summary>
        /// Mch = Machine
        /// </summary>
        #region Galil1 IOs
        //定义HWGalil1 input 1-8
        static public IObit IMchSystemAirOK          = new IObit(HWDevces.HWGalil1.IOInput0, 1);
        static public IObit IMchFrontDoorSafe1       = new IObit(HWDevces.HWGalil1.IOInput0, 2);
        static public IObit IMchFrontDoorSafe2       = new IObit(HWDevces.HWGalil1.IOInput0, 3);
        static public IObit IMchFrontDoorClosed      = new IObit(HWDevces.HWGalil1.IOInput0, 4);
        static public IObit IMchRearDoorSafe1        = new IObit(HWDevces.HWGalil1.IOInput0, 5);
        static public IObit IMchRearDoorSafe2        = new IObit(HWDevces.HWGalil1.IOInput0, 6);
        static public IObit IMchRearDoorClosed       = new IObit(HWDevces.HWGalil1.IOInput0, 7);
        static public IObit IMchEstopButtonOK        = new IObit(HWDevces.HWGalil1.IOInput0, 8);

        //定义HWGalil1 input 9-16
        //T3
        static public IObit IT3NestVac12OK          = new IObit(HWDevces.HWGalil1.IOInput0, 9);
        static public IObit IT3NestVac34OK          = new IObit(HWDevces.HWGalil1.IOInput0, 10);
        static public IObit IT3LeftXferVacOK        = new IObit(HWDevces.HWGalil1.IOInput0, 11);
        static public IObit IT3RightXferVacOK       = new IObit(HWDevces.HWGalil1.IOInput0, 12);
        //T3N
        static public IObit IT1NestPartPresent12    = new IObit(HWDevces.HWGalil1.IOInput0, 9);
        static public IObit IT1NestPartPresent34    = new IObit(HWDevces.HWGalil1.IOInput0, 10);
        static public IObit IT1SMACGripperExtended  = new IObit(HWDevces.HWGalil1.IOInput0, 11);
        static public IObit IT1SMACPartPresent      = new IObit(HWDevces.HWGalil1.IOInput0, 12);
        //UM
        static public IObit UMPartPresent_1         = new IObit(HWDevces.HWGalil1.IOInput0, 9);
        static public IObit UMPartPresent_2         = new IObit(HWDevces.HWGalil1.IOInput0, 10);
        static public IObit UMPartPresent_3         = new IObit(HWDevces.HWGalil1.IOInput0, 11);
        static public IObit UMPartPresent_4         = new IObit(HWDevces.HWGalil1.IOInput0, 12);
   
        //All modules
        static public IObit MchGearingGoNow         = new IObit(HWDevces.HWGalil1.IOInput0, 13);
        static public IObit MchEstopRelayOK         = new IObit(HWDevces.HWGalil1.IOInput0, 14);
        static public IObit MchRobotLoadEStopOK     = new IObit(HWDevces.HWGalil1.IOInput0, 15);
        static public IObit MchRobotUnloadEStopOK   = new IObit(HWDevces.HWGalil1.IOInput0, 16);


        //定义HWGalil1 Ouput0 Nest type1 T3N
        static public IObit T3NestVacLeft             = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 1);
        static public IObit T3NestPufLeft             = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 2);
        static public IObit T3NestVacRight            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 3);
        static public IObit T3NestPufRight            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 4);
        static public IObit T3XferVac                 = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 5);
        static public IObit T3XferPuf                 = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 6);
        static public IObit T3Spare1Y07               = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 7);
        static public IObit T3Spare1Y08               = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 8);       
        static public IObit T3NestFinger              = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 9);

        //T1L,T1S,T1N T2N Output1-4
        static public IObit T1NestExtendZClamps       = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 1);
        static public IObit T1NestExdLongFinger       = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 2);
        static public IObit T1NestExdShotFinger       = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 3);
        static public IObit T1SMACExtendGripper       = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 4);
        static public IObit T1Spare1Y05               = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 5);
        static public IObit T1Spare1Y06               = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 6);
        static public IObit T1Spare1Y07               = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 7);
        static public IObit T1Spare1Y08               = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 8);
        //UM
        static public IObit UMEndeff1Vac            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 1);
        static public IObit UMEndeff1Puff           = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 2);
        static public IObit UMEndeff2Vac            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 3);
        static public IObit UMEndeff2Puff           = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 4);
        static public IObit UMEjctor12Vac           = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 5);
        static public IObit UMEjector12Puff         = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 6);
        static public IObit UMEjectorExtend12       = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 7);
        static public IObit UMEjectorRetract12      = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 8);

        //All modules
        static public IObit MchLJVReset             = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 10);
        static public IObit MchGearingTrigger       = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 11);
        static public IObit MchAbortOutput          = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 12);
        static public IObit MchLJV_PRG_1            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 13);
        static public IObit MchLJV_PRG_2            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 14);
        static public IObit MchLJV_PRG_3            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 15);
        static public IObit MchLJV_PRG_4            = new IObit(HWDevces.HWGalil1.IOOutput0Exp, 16);
        #endregion

        #region Galil2 IOs
        static public IObit BridgeLeftVacOK         = new IObit(HWDevces.HWGalil2.IOInput0, 1);
        static public IObit BridgeRightVacOK        = new IObit(HWDevces.HWGalil2.IOInput0, 2);
        static public IObit BridgeLeftVac           = new IObit(HWDevces.HWGalil2.IOInput0, 1);
        static public IObit BridgeLeftPuff          = new IObit(HWDevces.HWGalil2.IOInput0, 2);
        static public IObit BridgeRightVac          = new IObit(HWDevces.HWGalil2.IOInput0, 3);
        static public IObit BridgeRightPuff         = new IObit(HWDevces.HWGalil2.IOInput0, 4);
        #endregion

        #region GalilRIO IOs
        static public IObit UMNest1VacOK            = new IObit(HWDevces.HWGalilRIO.IOInput0, 1);
        static public IObit UMNest2VacOK            = new IObit(HWDevces.HWGalilRIO.IOInput0, 2);
        static public IObit UMNest3VacOK            = new IObit(HWDevces.HWGalilRIO.IOInput0, 3);
        static public IObit UMNest4VacOK            = new IObit(HWDevces.HWGalilRIO.IOInput0, 4);
        static public IObit UMEndeff1VacOK          = new IObit(HWDevces.HWGalilRIO.IOInput0, 5);
        static public IObit UMEndeff2VacOK          = new IObit(HWDevces.HWGalilRIO.IOInput0, 6);
        static public IObit UMEjector12VacOK        = new IObit(HWDevces.HWGalilRIO.IOInput0, 7);
        static public IObit UMEjector12Exgend       = new IObit(HWDevces.HWGalilRIO.IOInput0, 8);
        static public IObit UMEjector12Retract      = new IObit(HWDevces.HWGalilRIO.IOInput0, 9);
        static public IObit UMEndeff3VacOK          = new IObit(HWDevces.HWGalilRIO.IOInput0, 10);
        static public IObit UMEndeff4VacOK          = new IObit(HWDevces.HWGalilRIO.IOInput0, 11);
        static public IObit UMEjector34VacOK        = new IObit(HWDevces.HWGalilRIO.IOInput0, 12);
        static public IObit UMEjector34Exgend       = new IObit(HWDevces.HWGalilRIO.IOInput0, 13);
        static public IObit UMEjector34Retract      = new IObit(HWDevces.HWGalilRIO.IOInput0, 14);
        static public IObit UMNest1PartPresent      = new IObit(HWDevces.HWGalilRIO.IOInput0, 15);
        static public IObit UMNest2PartPresent      = new IObit(HWDevces.HWGalilRIO.IOInput0, 16);
        static public IObit UMNest3PartPresent      = new IObit(HWDevces.HWGalilRIO.IOInput0, 17);
        static public IObit UMNest4PartPresent      = new IObit(HWDevces.HWGalilRIO.IOInput0, 18);
        static public IObit UMRotatorVacOK          = new IObit(HWDevces.HWGalilRIO.IOInput0, 19);
        static public IObit UMBRC1OK                = new IObit(HWDevces.HWGalilRIO.IOInput0, 20);
        static public IObit UMBRC2OK                = new IObit(HWDevces.HWGalilRIO.IOInput0, 21);

        static public IObit UMNest1Vac              = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 1);
        static public IObit UMNest1Puff             = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 2);
        static public IObit UMNest12Finger          = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 3);
        static public IObit UMNest2Vac              = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 4);
        static public IObit UMNest2Puff             = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 5);
        static public IObit UMNest34Finger          = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 6);
        static public IObit UMNest3Vac              = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 7);
        static public IObit UMNest3Puff             = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 8);
        static public IObit UMNest4Vac              = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 9);
        static public IObit UMNest4Puff             = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 10);
        static public IObit UMEndeff3Vac            = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 11);
        static public IObit UMEndeff3Puff           = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 12);
        static public IObit UMEndeff4Vac            = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 13);
        static public IObit UMEndeff4Puff           = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 14);
        static public IObit UMEjector34Vac          = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 15);
        static public IObit UMEjector34Puff         = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 16);
        static public IObit UMExtendEjector34       = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 17);
        static public IObit UMRetractEjector34      = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 18);
        static public IObit UMRotatorVac            = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 19);
        static public IObit UMRotatorPuff           = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 20);
        static public IObit UMBCR1Trig              = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 21);
        static public IObit UMBCR2Trig              = new IObit(HWDevces.HWGalilRIO.IOOutput0Exp, 22);
        #endregion
        static public List<IObit> GetNestBits(NestType nestType)
        {
            List<IObit> obits = new List<IObit>();
            switch (nestType)
            {
                case NestType.T1WithJHook12:
                    obits.Add(IOInterface.IT1NestPartPresent12);
                    obits.Add(IOInterface.T1NestExdLongFinger);
                    obits.Add(IOInterface.T1NestExdShotFinger);
                    obits.Add(IOInterface.T1NestExtendZClamps);
                    break;
                case NestType.T1WithJHook34:
                    obits.Add(IOInterface.IT1NestPartPresent34);
                    break;
                case NestType.T1KDeath:
                    break;
                case NestType.UMNest12:
                    break;
                case NestType.UMNest34:
                    break;
                case NestType.UMWithRotator12:
                    break;
                case NestType.T3NVaccum12:
                    break;
                case NestType.T3NVaccum34:
                    break;
                default:
                    break;
            }
            if (obits != null && obits.Count > 2)
            {
                for (int i = 0; i < obits.Count - 1; i++)
                {
                    for (int j = i + 1; j < obits.Count; j++)
                    {
                        if (obits[i].Id == obits[j].Id && obits[i].IOSource == obits[j].IOSource)
                        {
                            System.Diagnostics.Debug.WriteLine(obits[i].IOSource.ToString() + "ID:" + obits[i].Id.ToString() + "Defined more than 1");
                        }
                    }

                }
            }

            return obits;        
        }
    }
}
