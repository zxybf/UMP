﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace Machine
{
    /// <summary>
    /// GalilControlWPF.xaml 的交互逻辑
    /// </summary>
    public partial class GalilControlWPF : UserControl
    {
        public GalilControlWPF()
        {
            InitializeComponent();
        }
        public HWGalil hWGalil = HWDevces.HWGalil1;
        Nest nest12 = new Nest(NestType.T3NVaccum12);
        Thread threadCicleIO;
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            this.ControlGalil1Input0.FB.Visibility = Visibility.Collapsed;
            this.gridGalil.DataContext = this.hWGalil;
            this.ControlGalil1IO.DataContext = this.hWGalil.IOOutput0Exp;
            this.ControlGalil1IO.lbIOActual.DataContext = this.hWGalil.IOOutput0Act;
            this.ControlGalil1Input0.DataContext = this.hWGalil.IOInput0;
            this.ControlGalil1Input0.lbIOActual.Visibility = Visibility.Hidden;
            this.ContolGalil1Input0Force.DataContext = this.hWGalil.IOInput0;
            this.ControlGalil1Input0.lbIOActual.DataContext = this.hWGalil.IOInput0;
            threadCicleIO = new Thread(new ThreadStart(CicleIO));
            this.hWGalil.IOOutput0Act.Bit01 = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.hWGalil.IsConnected)
            {

                this.lbGalilInf.Content = this.hWGalil.Disconnect();
                this.btGalilConnect.Content = "Disconnected";
                this.hWGalil.IOInput0.IsFirstUpate = true;
                this.hWGalil.IOInput1.IsFirstUpate = true;
                this.hWGalil.IOInput2.IsFirstUpate = true;
                this.hWGalil.IOOutput0Act.IsFirstUpate = true;
                this.hWGalil.IOOutput0Exp.IsFirstUpate = true;
                this.hWGalil.IOInput0.IsFirstUpate = true;
                // this.btGalilConnect.Background = ;
            }
            else
            {
                this.lbGalilInf.Content = hWGalil.Connect();
                if (this.lbGalilInf.Content.ToString().Contains("ERROR")) return;
                //this.hWGalil.DigitalO0Exp = 180;
                this.btGalilConnect.Content = "Connected";
                //this.btGalilConnect.BackColor = Color.Green;
                threadCicleIO = new Thread(new ThreadStart(CicleIO));            }
        }
        private void CicleIO()
        {
            while (false)
            {
            }

        }



        private void BtSendCmd_Click(object sender, RoutedEventArgs e)
        {
            if (tbCmd.Text.Length > 0)
            {
                this.hWGalil.SendCommand(tbCmd.Text, true);
            }
        }

        private void TbCmd_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                this.hWGalil.SendCommand(tbCmd.Text, true);
            }
        }

        private void CheckBox_Unloaded(object sender, RoutedEventArgs e)
        {
            threadCicleIO.Abort();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Thread thread;
            if (nest12.NestIsUnSnug())  
                thread = new Thread(new ThreadStart(nest12.NestSnug));//创建线程
            else                        
                thread = new Thread(new ThreadStart(nest12.NestUnSnug));//创建线程

            thread.Start();
        }
    }
}
