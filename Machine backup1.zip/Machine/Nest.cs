﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Machine
{
    public enum NestType
    {
        T1WithJHook12,
        T1WithJHook34,
        T1KDeath,
        UMNest12,
        UMNest34,
        UMWithRotator12,
        T3NVaccum12,
        T3NVaccum34,
    }
    public  class Nest : IPartHandler
    {
        IObit partSence;
        IObit vaccumOrZClamp;        
        IObit LongFinger;  //T3只有longfinger
        IObit ShortFinger;
        IObit nestPuff;
        IObit umRotatorVac;  //Z模组上的rotator真空
        IObit partSenceumRotatorc;  //Z模组上的rotator真空
        IObit umRotatorPuff;  //Z模组上的rotator喷气
        Part part;

        public Nest(NestType nestType)
        {
            this.NestType = nestType;
            //this.IObits = IOInterface.GetNestBits(nestType);
            switch (this.NestType)   //根据Nest来设置IO
            {
                case NestType.T1WithJHook12:
                    this.partSence = IOInterface.IT1NestPartPresent12;
                    this.vaccumOrZClamp = IOInterface.T1NestExtendZClamps;
                    this.LongFinger = IOInterface.T1NestExdLongFinger;
                    this.ShortFinger = IOInterface.T1NestExdShotFinger;
                    break;
                case NestType.T1WithJHook34:
                    this.partSence = IOInterface.IT1NestPartPresent34;
                    this.vaccumOrZClamp = IOInterface.T1NestExtendZClamps;
                    this.LongFinger = IOInterface.T1NestExdLongFinger;
                    this.ShortFinger = IOInterface.T1NestExdShotFinger;
                    break;
                case NestType.T1KDeath:
                    break;
                case NestType.UMNest12:
                    break;
                case NestType.UMNest34:
                    break;
                case NestType.UMWithRotator12:
                    break;
                case NestType.T3NVaccum12:
                    this.partSence = IOInterface.IT3NestVac12OK;
                    this.vaccumOrZClamp = IOInterface.T3NestVacLeft;
                    this.LongFinger = IOInterface.T3NestFinger;
                    this.nestPuff = IOInterface.T3NestPufLeft;
                    break;
                case NestType.T3NVaccum34:
                    this.partSence = IOInterface.IT3NestVac34OK;
                    this.vaccumOrZClamp = IOInterface.T3NestVacRight;
                    this.LongFinger = IOInterface.T3NestFinger;
                    this.nestPuff = IOInterface.T3NestPufLeft;
                    break;
                default:
                    break;
            }
            this.NestIObits = new List<IObit>(7);
            if (partSence != null)      this.NestIObits.Add(partSence);
            if (vaccumOrZClamp != null) this.NestIObits.Add(vaccumOrZClamp);
            if (LongFinger != null)     this.NestIObits.Add(LongFinger);
            if (ShortFinger != null)    this.NestIObits.Add(ShortFinger);
            if (nestPuff != null)       this.NestIObits.Add(nestPuff);
            if (umRotatorVac != null)   this.NestIObits.Add(umRotatorVac);
            if (umRotatorPuff != null)  this.NestIObits.Add(umRotatorPuff);            
            Initialization();
        }
        public NestType NestType { get; private set; }
        public List<IObit> NestIObits { get; private set; }
        private void Initialization()
        {
            this.HasPartsExpect = this.partSence.Status;  //万一原来有料，IO动作后无料了，能处理异常
            switch (this.NestType)
            {
                case NestType.T1WithJHook12:
                case NestType.T1WithJHook34:
                    break;
                case NestType.T1KDeath:
                    break;
                case NestType.UMNest12:
                case NestType.UMNest34:
                    break;
                case NestType.UMWithRotator12:
                    break;
                case NestType.T3NVaccum12:
                case NestType.T3NVaccum34:
                    break;
                default:
                    break;
            }
        }
        private void InitAllIO()
        {
            if (NestIObits != null && NestIObits.Count > 2)
            {
                for (int i = 0; i < NestIObits.Count - 1; i++)
                {
                    for (int j = i + 1; j < NestIObits.Count; j++)
                    {
                        if (NestIObits[i].Id == NestIObits[j].Id && NestIObits[i].IOSource == NestIObits[j].IOSource)
                        {
                            System.Diagnostics.Debug.WriteLine(NestIObits[i].IOSource.ToString() + "ID:" + NestIObits[i].Id.ToString() + "Defined more than 1");
                        }
                    }

                }
            }
        }
        public bool NestIsSnug()
        {
            switch (this.NestType)
            {
                case NestType.T1WithJHook12:
                case NestType.T1WithJHook34:
                    return !LongFinger.Status && vaccumOrZClamp.Status && !ShortFinger.Status;
                case NestType.T1KDeath:
                    break;
                case NestType.UMNest12:
                case NestType.UMNest34:
                case NestType.T3NVaccum12:
                case NestType.T3NVaccum34:
                    return !LongFinger.Status && vaccumOrZClamp.Status;
                case NestType.UMWithRotator12:
                    return !LongFinger.Status && vaccumOrZClamp.Status && !umRotatorVac.Status && !partSenceumRotatorc.Status;
                default:
                    break;
            }
            return false;
        }
        public bool NestIsUnSnug()
        {
            switch (this.NestType)
            {
                case NestType.T1WithJHook12:
                case NestType.T1WithJHook34:
                    return LongFinger.Status && vaccumOrZClamp.Status && ShortFinger.Status;
                case NestType.T1KDeath:
                    break;
                case NestType.UMNest12:
                case NestType.UMNest34:
                case NestType.T3NVaccum12:
                case NestType.T3NVaccum34:
                    return LongFinger.Status && !vaccumOrZClamp.Status;
                case NestType.UMWithRotator12:
                    return LongFinger.Status && !vaccumOrZClamp.Status && !umRotatorVac.Status && !partSenceumRotatorc.Status;
                default:
                    break;
            }
            return false;
        }
        public void NestSnug()
        {
            if (NestIsSnug()) NestUnSnug();
            if (this.HasPartsExpect && this.nestPuff != null)  //如果有料要抓，先打开喷气
            {
                this.nestPuff.SB();
                Thread.Sleep(1000);
            }
            CloseFinger();
            Thread.Sleep(500);
            if (this.nestPuff != null) this.nestPuff.CB();
            if(this.NestType==NestType.T1WithJHook12|| this.NestType == NestType.T1WithJHook34) this.vaccumOrZClamp.CB(); //T1的是钩子，CB才是JHook下去压料
            else this.vaccumOrZClamp.SB();
            Thread.Sleep(500);

        }
        public void NestUnSnug()
        {
            if (NestIsUnSnug()) NestSnug();
            if (this.NestType == NestType.T1WithJHook12 || this.NestType == NestType.T1WithJHook34) this.vaccumOrZClamp.SB(); //T1的是钩子，CB才是JHook下去压料
            else this.vaccumOrZClamp.CB();
            if (this.nestPuff != null) this.nestPuff.CB();
            Thread.Sleep(500);
            if (this.ShortFinger != null) ShortFinger.SB();
            this.LongFinger.SB();
            Thread.Sleep(500);
        }
        private void CloseFinger()
        {
            if (this.NestType == NestType.T1WithJHook12 || this.NestType == NestType.T1WithJHook34) this.ShortFinger.CB();
            this.LongFinger.CB();
        }
        private void OpenFinger()
        {
            if (this.NestType == NestType.T1WithJHook12 || this.NestType == NestType.T1WithJHook34) this.ShortFinger.SB();
            this.LongFinger.SB();
        }
        #region IPartHandler Interface
        public IPartHandler PartSource { get; set; }
        public IPartHandler PartDestination { get; set; }
        public bool HasPartsSensor { get { return partSence.Status; } }
        public bool HasPartsExpect { get; private set; }
        public PartHandlerStatus PartHandlerStatus { get; set; }
        public bool ReadyForPick() { return ReadyForParts(); }       
        public bool Idle { get; }
        public Part PartRight { get => part; set => part = value; }
        public Part PartLeft { get => part; set => part = value; }
        public void GrabParts(Part partRight, Part partLeft) {this.PartRight = partRight;this.PartLeft = PartLeft; }
        public void ReleaseParts(bool _releaseVacuum) {; }
        public Part HandOverParts() { return this.PartRight; }      
        public void PickComplete()
        {
            ;
        }
        public bool ReadyForParts()
        {
            return !this.partSence.Status && !HasPartsExpect && NestIsUnSnug();
        }
        #endregion
    }
}
