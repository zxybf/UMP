﻿//*****************************************************************************
//*         FILE: HWDevces.cs
//*       AUTHOR: xinyiz163@163.com
//*         DATE: Dec 2019
//*  DESCRIPTION: 在此添加所有的IO控制设备如Galil DMC RIO, PLC... 
//*****************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Machine
{
    static public class HWDevces
    {
        static public HWGalil HWGalil1 = new HWGalil();
        static public HWGalil HWGalil2 = new HWGalil();
        static public HWGalil HWGalilRIO = new HWGalil();
    }
}
