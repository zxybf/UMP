﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Machine
{
    public class IObit
    {
        int _id;
        bool _status;
        IO iOSource;
        /// <summary>
        /// IO连线
        /// </summary>
        /// <param name="ioSource">IO bit连接到的IO硬件</param>
        /// <param name="id">连接IO硬件的哪一位</param>
        public IObit(IO ioSource, int id)
        {
            this.iOSource = ioSource;
            Id = id;
            Status = ioSource.IntBits[Id];
            ioSource.PropertyChanged += OnPropertyChange;
        }
        /// <summary>
        /// Set bit
        /// </summary>
        public void SB()
        {
            this.iOSource.IntBits[Id] = true;
        }
        /// <summary>
        /// Clear bit
        /// </summary>
        public void CB()
        {
            this.iOSource.IntBits[Id] = false;
        }

        /// <summary>
        /// 从1开始到16，如果超出则设置为1
        /// </summary>
        public int Id { get => _id; set { if (value < 1 || value > 17) _id = 0; else _id = value - 1; } } //value-1是由于IntBit是从0开始的
        public bool Status { get => _status; set => _status = value; }
        public IO IOSource { get => iOSource; }
        private void OnPropertyChange(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            Status = this.iOSource.IntBits[Id];  //TO DO:目前每个bit更新都会使得所有bit都更新，效率待提高
        }

    }
}
