﻿namespace UMP
{
    public class IOToggle
    {
        private string _description;
        private bool _ioBit;
        private ushort _num;
        private bool _isInputBit;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="num">编号</param>
        /// <param name="description">描述</param>
        /// /// <param name="description">描述</param>
        public IOToggle(bool isInputBit,ushort num, string description)
        {
            Description = description;
            this._num = num;
            this._isInputBit = isInputBit;            
        }

        /// <summary>
        /// Output描述
        /// </summary>
        public string Description { get => _description; set => _description = value; }

        /// <summary>
        /// 读取Output状态
        /// </summary>
        public bool IoBit { get => _ioBit; set => _ioBit = value; }

        /// <summary>
        /// Outut端口
        /// </summary>
        public ushort Num { get => _num; }
        public bool IsInputBit { get => _isInputBit; }
    }
}
