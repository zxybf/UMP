﻿namespace UMP
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.galil1Controller = new System.Windows.Forms.Integration.ElementHost();
            this.galilControlWPF1 = new UMP.GalilControlWPF();
            this.SuspendLayout();
            // 
            // galil1Controller
            // 
            this.galil1Controller.Dock = System.Windows.Forms.DockStyle.Fill;
            this.galil1Controller.Location = new System.Drawing.Point(0, 0);
            this.galil1Controller.Name = "galil1Controller";
            this.galil1Controller.Size = new System.Drawing.Size(982, 646);
            this.galil1Controller.TabIndex = 2;
            this.galil1Controller.Text = "elementHost1";
            this.galil1Controller.Child = this.galilControlWPF1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 646);
            this.Controls.Add(this.galil1Controller);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Integration.ElementHost galil1Controller;
        private GalilControlWPF galilControlWPF1;
    }
}

