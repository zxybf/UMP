﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UMP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //GalilIOControl galilControl;
        private void galilControl1_Load(object sender, EventArgs e)
        {
            //galilControl = new GalilIOControl(galilDI01);
            //this.panelInput.Controls.Add(galilControl);
           // galilControl.Location = new System.Drawing.Point(3, 3);
            //galilControl.Name = "DI01";
            //galilControl.TabIndex = 0;
            //galilControl.Size = new System.Drawing.Size(120, 27); 
            //this.Controls.Add(galilControl);
            //this.panelInput.Controls.Add(galilControl);
           
        }
        public IOToggle galilDI01 = new IOToggle(true, 0, "Vac OK");
    }
}
